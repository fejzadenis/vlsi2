Binaries that are expected to be fully functional, to be tested before publishing.

Warning: Do not use them in production, since occasionally they may be broken.
