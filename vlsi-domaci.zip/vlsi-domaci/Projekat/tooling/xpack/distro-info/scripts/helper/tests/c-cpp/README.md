Some of the files are from Martin's llvm-mingw project:

- <https://github.com/mstorsjo/llvm-mingw>

Chages:

- in the `hello-exception.cpp` file, the `wait` boolean variable was
  renamed `do_wait`, to avoid the clash with a system definition.

